//
//  ViewController.swift
//  FunctionDemo
//
//  Created by alpesh patel on 2/22/16.
//  Copyright © 2016 alpesh patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
      //  let someVar3 = PostalCode.CA(code: "AO15C")
       // let someVar3 = PostalCode.US("USACODE")
        //  let someVar3 = PostalCode.UK(10, 20)
        
        let someVar3 = PostalCode.uk(10, 20)

        
        // print("someVar1 =",someVar1,"someVar2=",someVar2,"someVar3=",someVar3)
        
        switch someVar3
        {
            case .uk (let s): print("UKValue---",s)
            case .us (let s): print("USValue---",s)
            case .ca (let s): print("CAValue---",s)
        }
        
        var emptyStr = [String]()
        
        emptyStr = ["aaa","bbbb"]
        print("emptyStr = ",emptyStr.count)
        
        Fn(first: 10, second: 20)
        Fn1(15, b: 25)
        fn2(1,2,3,4)
        
        
        let fnx = fn3(20)
        print("fnx = ",fnx)
        
        let r = fnx(3)
        print("r =",r)
        
        
        let Result = addMaker(30, b: 20, fnAdd: add)
        print("Result =", Result)
        
        
       let Name = GetName()
        print("Name =", Name)
        
        
        let Total = MultipleReturn(40, b: 50)
        print("Total =",Total)
          print("Total.Floor =",Total.Floor)
          print("Total.sum =",Total.Sum)
        
       let dob = ModifyInt(15, modify: double)
       let tri = ModifyInt(15, modify: Triple)
        print("dob =",dob)
        print("tri =",tri)
        
     
        
        let increment = BuildIncremetor()
         print("increment =",increment)
       
        let count = increment()
        print("count =",count)
        
        
        
        let Avg = average(10,20,30,40,50)
        print("Avg =",Avg)
        
        
        let ArrOfStr = ["I","am","an","Array"]
        let StrName = joinString(ArrOfStr)
        print("StrName =",StrName)
        
        
        let StrName2 = JoinString2("I","am","variadic")
        print("StrName2 =",StrName2)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//MARK:- Function Declaration
    func Fn(first a:Int , second b:Int)
    {
        print(a,b)
    }
    
    func Fn1(_ a:Int , b:Int)
    {
        print("Value of a =",a  ,"Value of b =",b)
    }

    func fn2(_ num:Int ...)
    {
        var sum=0
        
        print(num)
        
        for i in num
        {
            sum += i
        }
        
        print("sum=", sum)
    }
    
    
    func fn3(_ a:Int) ->(Int) ->Int
    {
        func inner(_ b:Int) -> Int
        {
            let innerVar = 22 + b
            print("Call inner fun")
            return innerVar
        }
        
        return inner
    }
    
    
    func add(_ a:Int, b:Int) -> Int
    {
        return a+b
    }
    
    func addMaker(_ a:Int, b:Int, fnAdd:(Int, Int) ->Int) -> Int
    {
        return fnAdd(a , b)
    }
    
    
    func GetName() -> (String, String)
    {
        return ("Alpesh", "Patel")
    }
    
    func MultipleReturn(_ a:Int, b:Int) -> (Sum:Int,Floor:Int)
    {
        let celling = a > b ? a : b
        let sum = a + b
        
        return (sum,celling)
    }
    
    func double(_ a:Int) -> Int
    {
        return a*2
    }
    
    func Triple(_ a:Int) -> Int
    {
        return a*3
    }
    
    func ModifyInt(_ num:Int ,modify:(Int) -> Int) -> Int
    {
       return modify(num)
    }
    
    
    func BuildIncremetor() -> () -> Int
    {
        var count=0
        
        func incrementor() -> Int
        {
                count += 1
            return count
        }
        
        return incrementor
    }
    
    func average(_ num:Int...) -> Int
    {
        var total = 0
        
        for n in num
        {
            total += n
        }
        
        return total / num.count
    }
    
    func joinString(_ Name: [String]) -> String
    {
        var returnStr = ""
        
        for str in Name
        {
            returnStr += str
        }
        
        return returnStr
    }
    
    func JoinString2(_ name:String...) -> String
    {
        return joinString(name)
    }
    
    
    enum PostalCode {
        case uk (Int, Int)
        case us (String)
        case ca (code:String)
    }
    
    
    
    
    
}

